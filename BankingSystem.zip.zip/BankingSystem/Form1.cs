﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BankingSystem
{
    public partial class Form1 : Form
    {
        List<string> nameArray = new List<string>();
        List<string> branchArray = new List<string>();
        List<string> TypeArray = new List<string>();
        List<double> CurrBalanceArray = new List<double>();


        public Form1()
        {
            InitializeComponent();
            int x = nameArray.Count;
            AccountNoLabel.Text = $ "Account No ";
        }









    }

}
       