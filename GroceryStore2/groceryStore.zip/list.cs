﻿using System.Collections.Generic;

namespace GroceryStore2
{
    internal class list<T> : List<string>
    {
    }
}