﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GroceryStore2
{
    public class Products
    {
        List<string> Product = new list<string>();
    }
    public void AddProduct(int ProductID, string Name, int Price, int InventoryLevel, int MiniInventoryLevel, int RequisitionAmount
}
